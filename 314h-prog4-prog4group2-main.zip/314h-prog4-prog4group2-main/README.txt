Name: Ari Ayzenberg and Smruti Sannabhadti
EID: aa95843 and sss5326
Email: aayzenberg2023@gmail.com and smrutis@utexas.edu
Time: ~50 hours and submitted between times of 4:50 pm and 5:00 on October 6th, 2023
Slip days: 1
Collaborators:
Comments:

