# !bash
# !usr/bin/env zsh

javac -d bin src/assignment/*.java
java -cp bin assignment.JTetris